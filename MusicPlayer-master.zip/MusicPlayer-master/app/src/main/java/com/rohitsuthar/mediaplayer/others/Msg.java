package com.rohitsuthar.mediaplayer.others;

import android.util.Log;

public class Msg {
    public static void log(String message) {
        Log.d("MEDIPLAY",message);
    }
}
